﻿namespace Ecommerce.Domain.Models;

public class FeatureProductConfiguration
{
    public long ProductId { get; set; }
    public int Order { get; set; }
}

