﻿namespace Ecommerce.Domain.Entities;
public class VariantImage
{
    public long VariantId { get; set; }
    public string ImageId { get; set; }
}