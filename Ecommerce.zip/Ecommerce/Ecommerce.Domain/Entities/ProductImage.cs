﻿namespace Ecommerce.Domain.Entities;
public class ProductImage
{
    public long ProductId { get; set; }
    public string ImageId { get; set; }
}