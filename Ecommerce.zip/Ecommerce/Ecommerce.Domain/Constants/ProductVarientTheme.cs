﻿namespace Ecommerce.Domain.Constants;

public static class ProductVariantTheme
{
    public const string Color = "Color";
    public const string Size = "Size";
    public const string ColorSize = "Color-Size";
}

