﻿namespace Ecommerce.Domain.Constants;

public static class AppMemoryCache
{
    public static string AppConfiguration = "AppConfiguration";
}

