﻿namespace Ecommerce.Web.Mvc.Constants;

public static class LayoutPage
{
    public static string ShopLayout = "_ShopLayout";
    public static string AdminLayout = "_AdminLayout";
    public static string CleanLayout = "_CleanLayout";
}
