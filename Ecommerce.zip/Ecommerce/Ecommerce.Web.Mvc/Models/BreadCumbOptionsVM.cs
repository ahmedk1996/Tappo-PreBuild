﻿namespace Ecommerce.Web.Mvc.Models;

public class BreadCumbOptionsVM
{
    public string Slug { get; set; }
    public bool IsLastLink { get; set; } = false;
}
