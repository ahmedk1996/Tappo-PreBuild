﻿namespace Ecommerce.Web.Mvc.Models;

public class BreadCumbVM
{
    public string Name { get; set; }
    public string Slug { get; set; }
}
