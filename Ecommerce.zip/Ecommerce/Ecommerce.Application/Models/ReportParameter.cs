﻿namespace Ecommerce.Application.Models;

public class ReportParameter
{
    public string Name { get; set; }
    public string Value { get; set; }
}
