﻿namespace Ecommerce.Application.Interfaces;

public interface IMemoryCacheManager
{
    void AppConfigurationRestore();
}
