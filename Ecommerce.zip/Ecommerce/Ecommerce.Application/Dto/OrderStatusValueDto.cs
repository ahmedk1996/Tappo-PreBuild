﻿namespace Ecommerce.Application.Dto;

public class OrderStatusValueDto
{
    public int Id { get; set; }
    public string StatusValue { get; set; }
    public string? Description { get; set; }
}
