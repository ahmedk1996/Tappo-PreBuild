﻿namespace Ecommerce.Application.Dto;

public class GalleryDto
{
    public string Id { get; set; }
    public string? Title { get; set; }
    public string? Name { get; set; }
    public string? Tags { get; set; }
}
