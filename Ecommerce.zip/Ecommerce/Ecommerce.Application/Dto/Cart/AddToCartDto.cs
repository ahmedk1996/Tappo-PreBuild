﻿namespace Ecommerce.Application.Dto;
public class AddToCartDto
{
    public long VariantId { get; set; }
    public int Qty { get; set; }
}