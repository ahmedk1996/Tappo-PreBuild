﻿namespace Ecommerce.Application.Dto;
public class HeaderSliderDto
{
    public string? Image { get; set; }
    public string? ImagePreview { get; set; }
    public string? HeaderTextLineOne { get; set; }
    public string? HeaderTextLineTwo { get; set; }
    public string? SubText { get; set; }
    public bool IsActive { get; set; }
    public int Order { get; set; }
}