﻿namespace Ecommerce.Application.Dto;

public class ProductSizesByColorFilterResultDto
{
    public int SizeId { get; set; }
    public string Name { get; set; }
}
