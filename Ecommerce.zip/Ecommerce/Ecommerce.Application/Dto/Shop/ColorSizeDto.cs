﻿namespace Ecommerce.Application.Dto.Shop;
public class ColorSizeDto
{
    public long VariantId { get; set; }
    public int ColorId { get; set; }
    public int SizeId { get; set; }
}
